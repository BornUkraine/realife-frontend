-- Protected quantity/SBT lock fields for Realife protected ERC-1155 flow
-- Safe/idempotent migration for PostgreSQL + Prisma migrate deploy.

-- Create enum if it does not exist yet.
DO $$
BEGIN
  CREATE TYPE "ProtectedNftLockStatus" AS ENUM (
    'NOT_REQUIRED',
    'PENDING_LOCKED',
    'COMPLETED_LOCKED',
    'RETURNED_TO_SELLER',
    'UNLOCKED',
    'INVALIDATED'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Holding lock snapshots.
ALTER TABLE "Holding"
  ADD COLUMN IF NOT EXISTS "pendingLockedAmount" BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS "completedLockedAmount" BIGINT NOT NULL DEFAULT 0;

-- StoreOrder protected lock lifecycle snapshots.
-- StoreOrder is mapped to the physical table "store_orders" in Prisma.
ALTER TABLE "store_orders"
  ADD COLUMN IF NOT EXISTS "protectedNftLockStatus" "ProtectedNftLockStatus" NOT NULL DEFAULT 'NOT_REQUIRED',
  ADD COLUMN IF NOT EXISTS "protectedNftPendingAmount" BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS "protectedNftCompletedAmount" BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS "protectedNftLockedAt" TIMESTAMP(3),
  ADD COLUMN IF NOT EXISTS "protectedNftCompletedAt" TIMESTAMP(3),
  ADD COLUMN IF NOT EXISTS "protectedNftUnlockedAt" TIMESTAMP(3);

-- Indexes matching schema.prisma.
CREATE INDEX IF NOT EXISTS "Holding_pendingLockedAmount_idx"
  ON "Holding"("pendingLockedAmount");

CREATE INDEX IF NOT EXISTS "Holding_completedLockedAmount_idx"
  ON "Holding"("completedLockedAmount");

CREATE INDEX IF NOT EXISTS "store_orders_protectedNftLockStatus_idx"
  ON "store_orders"("protectedNftLockStatus");

CREATE INDEX IF NOT EXISTS "store_orders_protectedNftPendingAmount_idx"
  ON "store_orders"("protectedNftPendingAmount");

CREATE INDEX IF NOT EXISTS "store_orders_protectedNftCompletedAmount_idx"
  ON "store_orders"("protectedNftCompletedAmount");
