Realife Prisma migration: protected_quantity_locks

Put this folder into your repo:

prisma/migrations/20260515200000_protected_quantity_locks/migration.sql

Then commit and push to GitHub. Railway should run:

npx prisma migrate deploy

This migration adds:
- enum ProtectedNftLockStatus
- Holding.pendingLockedAmount
- Holding.completedLockedAmount
- StoreOrder protected lock fields
- matching indexes

Important:
schema.prisma must already contain the same fields/enums.
